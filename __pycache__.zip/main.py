
# app/main.py
from fastapi import FastAPI
from sqlalchemy import text
from modules.database import engine
from modules.models import Base
from modules.routes import router as courses_router

app = FastAPI(title="Course API")

# Dev only: ensure tables exist
Base.metadata.create_all(bind=engine)

@app.on_event("startup")
def startup_check():
    with engine.connect() as conn:
        conn.execute(text("SELECT 1"))
        print("DB connection OK at startup")

modules.include_router(courses_router)
