import psycopg2
 
def connect_to_postgres():
    """ Connect to the PostgreSQL database server """
    connection = None
    try:
        # Define connection parameters
        params = {
            "dbname": "lms_db",
            "user": "lmsadmin",
            "password": "Lorem@784109",
            "host": "dev-lms-server.postgres.database.azure.com",

            "port": "5432" # Default PostgreSQL port
        }
 
        # Connect to the PostgreSQL server
        print('Connecting to the PostgreSQL database...')
        connection = psycopg2.connect(**params)
        
        # Create a cursor object for executing SQL queries
        cursor = connection.cursor()
        
        print("Connection successful!")
 
        # # Example: Execute a simple query
        # cursor.execute('SELECT version()')
 
        # # Fetch the result
        # db_version = cursor.fetchone()
        # print(f"PostgreSQL database version: {db_version}\n")
 
        # Close the cursor and connection
        cursor.close()
        connection.close()
 
    except (Exception, psycopg2.DatabaseError) as error:
        print(f"An error occurred: {error}")
    finally:
        if connection is not None:
            connection.close()
            print('Database connection closed.')
 
if __name__ == '__main__':
    connect_to_postgres()