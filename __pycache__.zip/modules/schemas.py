
# app/schemas.py
from pydantic import BaseModel, Field, HttpUrl, ConfigDict
from typing import Optional
from datetime import datetime

class CourseBase(BaseModel):
    title: str = Field(..., min_length=1)
    
    description: Optional[str] = None
    category: str = Field(..., min_length=1)
    level: Optional[str] = None
    language: Optional[str] = None
    thumbnail_url: Optional[HttpUrl] = None
    price: Optional[float] = None
    is_free: bool = False
    total_videos: int = 0
    total_duration_seconds: int = 0
    status: Optional[str] = "draft"

class CourseCreate(CourseBase):
    """Fields required when creating a course.
    You may enforce required ones here if needed."""
    pass

class CourseUpdate(BaseModel):
    """All fields optional for partial updates (PATCH)."""
    title: Optional[str] = None
    category: Optional[str] = None
    description: Optional[str] = None
    level: Optional[str] = None
    language: Optional[str] = None
    thumbnail_url: Optional[HttpUrl] = None
    price: Optional[float] = None
    is_free: Optional[bool] = None
    total_videos: Optional[int] = None
    total_duration_seconds: Optional[int] = None
    status: Optional[str] = None

class CourseResponse(CourseBase):
    id: int
    created_at: datetime
    updated_at: datetime

    # Pydantic v2 ORM mode
    model_config = ConfigDict(from_attributes=True)
