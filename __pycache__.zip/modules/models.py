
# app/models.py
from sqlalchemy import Column, Integer, String, Boolean, Float, DateTime
from sqlalchemy.orm import declarative_base
from datetime import datetime

Base = declarative_base()

class Course(Base):
    __tablename__ = "courses"

    id = Column(Integer, primary_key=True, index=True)
    title = Column(String, nullable=False)
    
    description = Column(String, nullable=True)
    category = Column(String, nullable=False)
    level = Column(String, nullable=True)
    language = Column(String, nullable=True)
    thumbnail_url = Column(String, nullable=True)
    price = Column(Float, nullable=True)          # price as number
    is_free = Column(Boolean, default=False)       # boolean
    total_videos = Column(Integer, default=0)
    total_duration_seconds = Column(Integer, default=0)
    status = Column(String, default="draft")       # e.g., "draft" | "published"
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)