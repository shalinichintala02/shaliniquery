
# app/routes.py
import logging
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy.exc import SQLAlchemyError
from modules.models import Course
from modules.schemas import CourseCreate, CourseResponse
from modules.database import Base
logger = logging.getLogger("uvicorn.error")  # Uvicorn logger

router = APIRouter(prefix="/courses", tags=["courses"])

@router.post("/", response_model=CourseResponse, status_code=201)
def create_course(payload: CourseCreate, db: Session = Depends(Base)):
    try:
        course = Course(**payload.model_dump())
        db.add(course)
        db.commit()
        db.refresh(course)
        return course
    except SQLAlchemyError as e:
        db.rollback()
        logger.exception("Database error while creating course")
        raise HTTPException(status_code=500, detail="Database error")
    except Exception as e:
        logger.exception("Unexpected error while creating course")
        raise HTTPException(status_code=500, detail="Unexpected error")
